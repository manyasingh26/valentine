![Image of Valentines Message 4 U site](https://i.imgur.com/SISrpEH.png)

# A Site To Send Mobile Valentines To My Friends

This Valentines, 2025, I wanted to let all my friends know how much they mean to me via Lego Valentines! Randomized ofc!

Also using [system.css](https://sakofchit.github.io/system.css/) for some of the styling. Cheers!
